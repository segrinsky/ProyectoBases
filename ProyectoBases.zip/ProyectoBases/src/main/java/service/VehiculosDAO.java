package service;

import model.Estilo;
import model.TipoVehiculo;
import model.Transmision;
import model.Vehiculo;
import model.hospitales.Hospital;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VehiculosDAO {

    public static List<Vehiculo> obtenerVehiculos() {
        List<Vehiculo> vehiculos = new ArrayList<>();

        try (Connection connection = Conexion.obtenerConexion()) {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM VehiculosVista");
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int idVehiculo = resultSet.getInt("id_vehiculo");
                String tipoVehiculo = resultSet.getString("tipo_vehiculo");
                String estilo = resultSet.getString("estilo");
                String transmision = resultSet.getString("transmision");
                String descripcion = resultSet.getString("descripcion");
                int cantidad = resultSet.getInt("cantidad");
                String anoFabricacion = resultSet.getString("ano_fabricacion");
                int cantidadPuertas = resultSet.getInt("cantidad_puertas");
                double precio = resultSet.getDouble("precio");

                Vehiculo vehiculo = new Vehiculo(idVehiculo, tipoVehiculo, estilo, transmision, descripcion, cantidad, anoFabricacion, cantidadPuertas, precio);
                vehiculos.add(vehiculo);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener los datos de la tabla VehiculosVista: " + e.getMessage());
        }

        return vehiculos;
    }

    public static List<Transmision> obtenerTransmisiones() {
        List<Transmision> transmisiones = new ArrayList<>();

        try (Connection connection = Conexion.obtenerConexion()) {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Transmisiones");
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int idTransmision = resultSet.getInt("id_transmision");
                String transmision = resultSet.getString("transmision");

                Transmision transmisionObj = new Transmision(idTransmision, transmision);
                transmisiones.add(transmisionObj);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener los datos de la tabla Transmisiones: " + e.getMessage());
        }

        return transmisiones;
    }

    public static List<Estilo> obtenerEstilos() {
        List<Estilo> estilos = new ArrayList<>();

        try (Connection connection = Conexion.obtenerConexion()) {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Estilos");
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int idEstilo = resultSet.getInt("id_estilo");
                String estilo = resultSet.getString("estilo");

                Estilo estiloObj = new Estilo(idEstilo, estilo);
                estilos.add(estiloObj);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener los datos de la tabla Estilos: " + e.getMessage());
        }

        return estilos;
    }

    public static List<TipoVehiculo> obtenerTiposVehiculo() {
        List<TipoVehiculo> tiposVehiculo = new ArrayList<>();

        try (Connection connection = Conexion.obtenerConexion()) {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM TipoVehiculo");
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int idTipoVehiculo = resultSet.getInt("id_tipo_vehiculo");
                int idTipoTransporte = resultSet.getInt("id_tipo_transporte");
                String tipoVehiculo = resultSet.getString("tipo_vehiculo");

                TipoVehiculo tipoVehiculoObj = new TipoVehiculo(idTipoVehiculo, idTipoTransporte, tipoVehiculo);
                tiposVehiculo.add(tipoVehiculoObj);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener los datos de la tabla TipoVehiculo: " + e.getMessage());
        }

        return tiposVehiculo;
    }
//    public static List<Hospital> obtenerVehiculo(){
//        List<Vehiculo> hospitales = new ArrayList<>();
//
//        try (Connection connection = Conexion.obtenerConexion()){
//            PreparedStatement preparedStatement = connection.prepareStatement("select * from HOSPITAL");
//            ResultSet resultSet = preparedStatement.executeQuery();
//
//            while (resultSet.next()){
//                int id = resultSet.getInt("ID_HOSPITAL");
//                String nombre = resultSet.getString("NOMBRE");
//                String direccion = resultSet.getString("DIRECCION");
//
//                Hospital hospital = new Hospital(id, nombre, direccion);
//                hospitales.add(hospital);
//            }
//
//        } catch (SQLException e) {
//            System.err.println("Error al obtener los datos de la tabla " + e.getMessage());
//        }
//
//        return hospitales;
//    }

//    public static void insertHospital(Hospital hospital){
//        try (Connection connection = Conexion.obtenerConexion()){
//            String query = "INSERT INTO Vehiculos VALUES(?, ?)";
//
//            PreparedStatement preparedStatement = connection.prepareStatement(query);
//            preparedStatement.setString(1, hospital.getNombre());
//            preparedStatement.setString(2, hospital.getDireccion());
//
//            preparedStatement.execute();
//
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//    }

//    public static void updateHospital(Hospital hospital){
//        try (Connection connection = Conexion.obtenerConexion()){
//            String query = "UPDATE Vehiculos SET " +
//                    "NOMBRE=?, " +
//                    "DIRECCION=? " +
//                    "WHERE ID_HOSPITAL=?";
//
//            PreparedStatement preparedStatement = connection.prepareStatement(query);
//            preparedStatement.setString(1, hospital.getNombre());
//            preparedStatement.setString(2, hospital.getDireccion());
//            preparedStatement.setInt(3, hospital.getIdHospital());
//
//            preparedStatement.execute();
//
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//    }

//    public static void deleteHospital(int idHospital){
//        try (Connection connection = Conexion.obtenerConexion()){
//            String query = "DELETE FROM Vehiculos WHERE ID_HOSPITAL = ?";
//
//            PreparedStatement preparedStatement = connection.prepareStatement(query);
//            preparedStatement.setInt(1, idHospital);
//            preparedStatement.execute();
//
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//    }

//    public static Hospital getHospital(int idHospital){
//        Hospital hospital = new Hospital();
//        try (Connection connection = Conexion.obtenerConexion()){
//            String query = "SELECT * FROM HOSPITAL WHERE ID_HOSPITAL = ?";
//
//            PreparedStatement preparedStatement = connection.prepareStatement(query);
//            preparedStatement.setInt(1, idHospital);
//            ResultSet resultSet = preparedStatement.executeQuery();
//
//            resultSet.next();
//            hospital.setIdHospital(resultSet.getInt("ID_HOSPITAL"));
//            hospital.setNombre(resultSet.getString("NOMBRE"));
//            hospital.setDireccion(resultSet.getString("DIRECCION"));
//
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//
//        return hospital;
//    }

//    public static boolean hospitalExists(int idHospital){
//        try (Connection connection = Conexion.obtenerConexion()){
//            String query = "SELECT * FROM HOSPITAL WHERE ID_HOSPITAL = ?";
//
//            PreparedStatement preparedStatement = connection.prepareStatement(query);
//            preparedStatement.setInt(1, idHospital);
//            ResultSet resultSet = preparedStatement.executeQuery();
//
//            return resultSet.next();
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//    }

    public static String mostrarVehiculos(){
        List<Vehiculo> vehiculos = obtenerVehiculos();
        StringBuilder listaVehiculos = new StringBuilder("Lista de Vehiculos");
        if (vehiculos.isEmpty()) {
            listaVehiculos.append(" vacia");
            System.out.println(listaVehiculos);
        }
        else {
            for (Vehiculo hospital : vehiculos) {
                listaVehiculos.append("\n").append(hospital);
            }
            System.out.println(listaVehiculos);
        }

        return listaVehiculos.toString();
    }
}
