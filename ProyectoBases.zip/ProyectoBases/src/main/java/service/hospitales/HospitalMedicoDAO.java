package service.hospitales;

import model.hospitales.HospitalMedico;
import service.Conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HospitalMedicoDAO {
    public static List<HospitalMedico> obtenerHospitalMedico(){
        List<HospitalMedico> hospitalMedicos = new ArrayList<>();

        try (Connection connection = Conexion.obtenerConexion()){
            PreparedStatement preparedStatement = connection.prepareStatement("select * from HOSPITAL_MEDICO");
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()){
                int idHospital = resultSet.getInt("ID_HOSPITAL");
                int cedula = resultSet.getInt("CEDULA");

                HospitalMedico hospitalMedico = new HospitalMedico(cedula, idHospital);
                hospitalMedicos.add(hospitalMedico);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener los datos de la tabla " + e.getMessage());
        }

        return hospitalMedicos;
    }

    public static void insertHospitalMedico(HospitalMedico hospitalMedico){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "INSERT INTO HOSPITAL_MEDICO VALUES(?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, hospitalMedico.getIdHospital());
            preparedStatement.setInt(2, hospitalMedico.getCedula());

            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void updateHospitalMedico(HospitalMedico hospitalMedicoViejo, int idHospital){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "UPDATE HOSPITAL_MEDICO SET " +
                    "ID_HOSPITAL=? " +
                    "WHERE ID_HOSPITAL = ? AND CEDULA=?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idHospital);
            preparedStatement.setInt(2, hospitalMedicoViejo.getIdHospital());
            preparedStatement.setInt(3, hospitalMedicoViejo.getCedula());

            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void deleteHospitalMedico(int idHospital, int cedula){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "DELETE FROM HOSPITAL_MEDICO WHERE ID_HOSPITAL = ? AND CEDULA = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idHospital);
            preparedStatement.setInt(2, cedula);
            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static HospitalMedico getHospitalMedico(int idHospital, int cedula){
        HospitalMedico hospitalMedico = new HospitalMedico();
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "SELECT * FROM HOSPITAL_MEDICO WHERE ID_HOSPITAL = ? AND CEDULA = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idHospital);
            preparedStatement.setInt(2, cedula);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            hospitalMedico.setIdHospital(resultSet.getInt("ID_HOSPITAL"));
            hospitalMedico.setCedula(resultSet.getInt("CEDULA"));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return hospitalMedico;
    }

    public static String mostrarHospitalMedicos(){
        List<HospitalMedico> hospitalMedicos = obtenerHospitalMedico();
        StringBuilder listaHospitales = new StringBuilder("Lista de hospitales-medicos");

        if (hospitalMedicos.isEmpty()) listaHospitales.append(" vacia");
        else {

            for (HospitalMedico hospitalMedico : hospitalMedicos) {
                listaHospitales.append("\n").append(hospitalMedico);
            }
        }

        return listaHospitales.toString();
    }

    public static void deleteAllMedico(int cedula) {
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "DELETE FROM HOSPITAL_MEDICO WHERE CEDULA = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, cedula);
            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void deleteAllHospital(int idHospital) {
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "DELETE FROM HOSPITAL_MEDICO WHERE ID_HOSPITAL = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idHospital);
            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static boolean registerExist(int cedula, int idHospital) {
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "SELECT * FROM HOSPITAL_MEDICO WHERE ID_HOSPITAL = ? AND CEDULA = ? ";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idHospital);
            preparedStatement.setInt(2, cedula);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean medicoExist(int cedula) {
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "SELECT * FROM HOSPITAL_MEDICO WHERE CEDULA = ? ";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, cedula);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
