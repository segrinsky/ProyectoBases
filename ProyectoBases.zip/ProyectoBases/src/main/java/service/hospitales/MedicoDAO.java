package service.hospitales;

import model.hospitales.Medico;
import service.Conexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicoDAO {
    public static List<Medico> obtenerMedico(){
        List<Medico> medicos = new ArrayList<>();

        try (Connection connection = Conexion.obtenerConexion()){
            PreparedStatement preparedStatement = connection.prepareStatement("select * from MEDICO");
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()){
                int cedula = resultSet.getInt("CEDULA");
                String nombre = resultSet.getString("NOMBRE");
                String apellido1 = resultSet.getString("APELLIDO_1");
                String apellido2 = resultSet.getString("APELLIDO_2");
                Date fecNacimiento = resultSet.getDate("FEC_NACIMIENTO");
                int edad = resultSet.getInt("EDAD");

                Medico medico = new Medico(cedula, nombre, apellido1, apellido2, fecNacimiento, edad);
                medicos.add(medico);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener los datos de la tabla " + e.getMessage());
        }

        return medicos;
    }

    public static void insertMedico(Medico medico){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "INSERT INTO MEDICO VALUES(?, ?, ?, ?, ?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, medico.getCedula());
            preparedStatement.setString(2, medico.getNombre());
            preparedStatement.setString(3, medico.getApellido1());
            preparedStatement.setString(4, medico.getApellido2());
            preparedStatement.setDate(5, medico.getFecNacimiento());
            preparedStatement.setInt(6, medico.getEdad());

            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void updateMedico(Medico medico){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "UPDATE MEDICO SET " +
                    "NOMBRE=?, " +
                    "APELLIDO_1=?, " +
                    "APELLIDO_2=?, " +
                    "FEC_NACIMIENTO=?, " +
                    "EDAD=? " +
                    "WHERE CEDULA=?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, medico.getNombre());
            preparedStatement.setString(2, medico.getApellido1());
            preparedStatement.setString(3, medico.getApellido2());
            preparedStatement.setDate(4, medico.getFecNacimiento());
            preparedStatement.setInt(5, medico.getEdad());
            preparedStatement.setInt(6, medico.getCedula());

            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void deleteMedico(int cedula){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "DELETE FROM MEDICO WHERE CEDULA = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, cedula);
            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static Medico getMedico(int cedula){
        Medico medico = new Medico();
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "SELECT * FROM MEDICO WHERE CEDULA = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, cedula);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            medico.setCedula(resultSet.getInt("CEDULA"));
            medico.setNombre(resultSet.getString("NOMBRE"));
            medico.setApellido1(resultSet.getString("APELLIDO_1"));
            medico.setApellido2(resultSet.getString("APELLIDO_2"));
            medico.setFecNacimiento(resultSet.getDate("FEC_NACIMIENTO"));
            medico.setEdad(resultSet.getInt("EDAD"));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return medico;
    }

    public static boolean medicoExists(int cedula){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "SELECT * FROM MEDICO WHERE CEDULA = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, cedula);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static String mostrarPacientes(){
        List<Medico> medicos = obtenerMedico();
        StringBuilder medicosStr = new StringBuilder("Lista de Medicos");

        if (medicos.isEmpty()) medicosStr.append(" vacia");
        else {

            for (Medico medico : medicos) {
                medicosStr.append("\n").append(medico);
            }
        }

        return medicosStr.toString();
    }
}
