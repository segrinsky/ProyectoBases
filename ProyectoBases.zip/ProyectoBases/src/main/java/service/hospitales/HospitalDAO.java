package service.hospitales;

import model.hospitales.Hospital;
import service.Conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HospitalDAO {
    public static List<Hospital> obtenerHospital(){
        List<Hospital> hospitales = new ArrayList<>();

        try (Connection connection = Conexion.obtenerConexion()){
            PreparedStatement preparedStatement = connection.prepareStatement("select * from HOSPITAL");
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()){
                int id = resultSet.getInt("ID_HOSPITAL");
                String nombre = resultSet.getString("NOMBRE");
                String direccion = resultSet.getString("DIRECCION");

                Hospital hospital = new Hospital(id, nombre, direccion);
                hospitales.add(hospital);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener los datos de la tabla " + e.getMessage());
        }

        return hospitales;
    }

    public static void insertHospital(Hospital hospital){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "INSERT INTO HOSPITAL VALUES(?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, hospital.getNombre());
            preparedStatement.setString(2, hospital.getDireccion());

            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void updateHospital(Hospital hospital){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "UPDATE HOSPITAL SET " +
                    "NOMBRE=?, " +
                    "DIRECCION=? " +
                    "WHERE ID_HOSPITAL=?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, hospital.getNombre());
            preparedStatement.setString(2, hospital.getDireccion());
            preparedStatement.setInt(3, hospital.getIdHospital());

            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void deleteHospital(int idHospital){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "DELETE FROM HOSPITAL WHERE ID_HOSPITAL = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idHospital);
            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static Hospital getHospital(int idHospital){
        Hospital hospital = new Hospital();
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "SELECT * FROM HOSPITAL WHERE ID_HOSPITAL = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idHospital);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            hospital.setIdHospital(resultSet.getInt("ID_HOSPITAL"));
            hospital.setNombre(resultSet.getString("NOMBRE"));
            hospital.setDireccion(resultSet.getString("DIRECCION"));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return hospital;
    }

    public static boolean hospitalExists(int idHospital){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "SELECT * FROM HOSPITAL WHERE ID_HOSPITAL = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idHospital);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static String mostrarHospitales(){
        List<Hospital> hospitales = obtenerHospital();
        StringBuilder listaHospitales = new StringBuilder("Lista de hospitales");

        if (hospitales.isEmpty()) listaHospitales.append(" vacia");
        else {

            for (Hospital hospital : hospitales) {
                listaHospitales.append("\n").append(hospital);
            }
        }

        return listaHospitales.toString();
    }
}
