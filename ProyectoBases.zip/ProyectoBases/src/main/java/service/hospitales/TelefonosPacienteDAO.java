package service.hospitales;

import model.hospitales.TelefonosPaciente;
import service.Conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TelefonosPacienteDAO {
    public static List<TelefonosPaciente> obtenerTelefonoPaciente(){
        List<TelefonosPaciente> PacienteTelefono = new ArrayList<>();

        try (Connection connection = Conexion.obtenerConexion()){
            PreparedStatement preparedStatement = connection.prepareStatement("select * from TELEFONOS_PACIENTE");
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()){
                int cedula = resultSet.getInt("CEDULA");
                int telefono = resultSet.getInt("TELEFONO");

                TelefonosPaciente pacienteTelefono = new TelefonosPaciente(cedula, telefono);
                PacienteTelefono.add(pacienteTelefono);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener los datos de la tabla " + e.getMessage());
        }

        return PacienteTelefono;
    }

    public static void insertTelefonoPaciente(TelefonosPaciente telefonosPaciente){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "INSERT INTO TELEFONOS_PACIENTE VALUES(?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, telefonosPaciente.getCedula());
            preparedStatement.setInt(2, telefonosPaciente.getTelefono());

            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void updateTelefonoPaciente(TelefonosPaciente telefonosPacienteViejo, int telefonosPacienteNuevo){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "UPDATE TELEFONOS_PACIENTE SET " +
                    "TELEFONO=? " +
                    "WHERE CEDULA=? AND TELEFONO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, telefonosPacienteNuevo);
            preparedStatement.setInt(2, telefonosPacienteViejo.getCedula());
            preparedStatement.setInt(3, telefonosPacienteViejo.getTelefono());

            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void deleteTelefonoPaciente(int cedula, int telefono){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "DELETE FROM TELEFONOS_PACIENTE WHERE CEDULA = ? AND TELEFONO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, cedula);
            preparedStatement.setInt(2, telefono);
            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static TelefonosPaciente getTelefonoPaciente(int cedula, int telefono){
        TelefonosPaciente telefonosPaciente = new TelefonosPaciente();
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "SELECT * FROM TELEFONOS_PACIENTE WHERE CEDULA = ? AND TELEFONO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, cedula);
            preparedStatement.setInt(2, telefono);
            ResultSet resultSet = preparedStatement.executeQuery();
            resultSet.next();

            telefonosPaciente.setCedula(resultSet.getInt("CEDULA"));
            telefonosPaciente.setTelefono(resultSet.getInt("TELEFONO"));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return telefonosPaciente;
    }

    public static boolean registerExist(int cedula, int telefono){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "SELECT * FROM TELEFONOS_PACIENTE WHERE CEDULA = ? AND TELEFONO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, cedula);
            preparedStatement.setInt(2, telefono);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void deleteAll(int cedula){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "DELETE FROM TELEFONOS_PACIENTE WHERE CEDULA = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, cedula);
            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static String mostrarTelefonosPaciente(){
        List<TelefonosPaciente> telefonosPaciente = obtenerTelefonoPaciente();
        StringBuilder listaTelefonosPaciente = new StringBuilder("Lista de Telefonos de Paciente");

        if (telefonosPaciente.isEmpty()) listaTelefonosPaciente.append(" vacia");
        else {

            for (TelefonosPaciente telefonoPaciente : telefonosPaciente) {
                listaTelefonosPaciente.append("\n").append(telefonoPaciente);
            }
        }

        return listaTelefonosPaciente.toString();
    }
}
