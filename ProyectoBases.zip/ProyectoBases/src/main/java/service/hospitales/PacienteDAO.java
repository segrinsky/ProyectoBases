package service.hospitales;

import model.hospitales.Paciente;
import service.Conexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {
    public static List<Paciente> obtenerPacientes(){
        List<Paciente> pacientes = new ArrayList<>();

        try (Connection connection = Conexion.obtenerConexion()){
            PreparedStatement preparedStatement = connection.prepareStatement("select * from PACIENTE");
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()){
                int cedula = resultSet.getInt("CEDULA");
                String nombre = resultSet.getString("NOMBRE");
                String apellido1 = resultSet.getString("APELLIDO_1");
                String apellido2 = resultSet.getString("APELLIDO_2");
                Date fecNacimiento = resultSet.getDate("FEC_NACIMIENTO");
                int edad = resultSet.getInt("EDAD");

                Paciente paciente = new Paciente(cedula, nombre, apellido1, apellido2, fecNacimiento, edad);
                pacientes.add(paciente);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener los datos de la tabla " + e.getMessage());
        }

        return pacientes;
    }

    public static void insertPaciente(Paciente paciente){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "INSERT INTO PACIENTE VALUES(?, ?, ?, ?, ?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, paciente.getCedula());
            preparedStatement.setString(2, paciente.getNombre());
            preparedStatement.setString(3, paciente.getApellido1());
            preparedStatement.setString(4, paciente.getApellido2());
            preparedStatement.setDate(5, paciente.getFecNacimiento());
            preparedStatement.setInt(6, paciente.getEdad());

            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void updatePaciente(Paciente paciente){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "UPDATE PACIENTE SET " +
                    "NOMBRE=?, " +
                    "APELLIDO_1=?, " +
                    "APELLIDO_2=?, " +
                    "FEC_NACIMIENTO=?, " +
                    "EDAD=? " +
                    "WHERE CEDULA=?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, paciente.getNombre());
            preparedStatement.setString(2, paciente.getApellido1());
            preparedStatement.setString(3, paciente.getApellido2());
            preparedStatement.setDate(4, paciente.getFecNacimiento());
            preparedStatement.setInt(5, paciente.getEdad());
            preparedStatement.setInt(6, paciente.getCedula());

            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void deletePaciente(int cedula){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "DELETE FROM PACIENTE WHERE CEDULA = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, cedula);
            preparedStatement.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static Paciente getPaciente(int cedula){
        Paciente paciente = new Paciente();
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "SELECT * FROM PACIENTE WHERE CEDULA = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, cedula);
            ResultSet resultSet = preparedStatement.executeQuery();

            resultSet.next();
            paciente.setCedula(resultSet.getInt("CEDULA"));
            paciente.setNombre(resultSet.getString("NOMBRE"));
            paciente.setApellido1(resultSet.getString("APELLIDO_1"));
            paciente.setApellido2(resultSet.getString("APELLIDO_2"));
            paciente.setFecNacimiento(resultSet.getDate("FEC_NACIMIENTO"));
            paciente.setEdad(resultSet.getInt("EDAD"));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return paciente;
    }

    public static boolean pacienteExists(int cedula){
        try (Connection connection = Conexion.obtenerConexion()){
            String query = "SELECT * FROM PACIENTE WHERE CEDULA = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, cedula);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static String mostrarPacientes(){
        List<Paciente> pacientes = obtenerPacientes();
        StringBuilder pacientesStr = new StringBuilder("Lista de Pacientes");

        if (pacientes.isEmpty()) pacientesStr.append(" está vacia");
        else {

            for (Paciente paciente : pacientes) {
                pacientesStr.append("\n").append(paciente);
            }
        }

        return pacientesStr.toString();
    }
}
