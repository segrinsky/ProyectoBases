package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    public static Connection obtenerConexion() {
        String url =
               "jdbc:sqlserver://localhost:1433;databaseName=BDAgenciasVehiculos;encrypt=false;trustServerCertificate=true;loginTimeout=5";

        String user = "sa"; //Poner aquí su usuario de la base de datos
        String password = "1234"; //Poner aquí la contraseña de la base de datos
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
}
