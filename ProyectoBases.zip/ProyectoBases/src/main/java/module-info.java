module com.example.interfaz_bases {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens ucr.proyectobases to javafx.fxml;
    opens model to javafx.base;
    exports ucr.proyectobases;
    exports controller;
    opens controller to javafx.fxml;
    exports controller.gestion;
    opens controller.gestion to javafx.fxml;
    exports controller.agregar;
    opens controller.agregar to javafx.fxml;
    opens controller.editar to javafx.fxml;
    exports controller.editar;
    opens model.hospitales to javafx.base;
}