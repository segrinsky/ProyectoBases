package controller.editar;

import controller.gestion.GestionHospitalesController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import model.hospitales.Hospital;
import service.hospitales.HospitalDAO;

public class EditarHospitalController {

    @FXML
    private Label Alerta;

    @FXML
    private TextField direccionTxt;

    @FXML
    private Text idTxt;
    private Alert alert;

    Hospital hospital;
    GestionHospitalesController gestionHospitalesController;
    @FXML
    private TextField nombreTxt;

    @FXML
    void btnAgregarOnAction(ActionEvent event) {
        if (isValid()){
            int idHospital = Integer.parseInt(idTxt.getText());
            String nombre = nombreTxt.getText();
            String direccion = direccionTxt.getText();

            Hospital hospitalNuevo = new Hospital(idHospital, nombre, direccion);
            HospitalDAO.updateHospital(hospitalNuevo);
            gestionHospitalesController.seteo();
            gestionHospitalesController.stage.close();
        }
    }

    @FXML
    void btnCancelarOnAction(ActionEvent event) {
        gestionHospitalesController.stage.close();
    }

    @FXML
    void btnLimpiarOnAction(ActionEvent event) {
        nombreTxt.setText("");
        direccionTxt.setText("");
        Alerta.setText("");
    }

    public void loadController(GestionHospitalesController gestionHospitalesController, int idHospital) {
        this.gestionHospitalesController = gestionHospitalesController;
        seteo(idHospital);
    }

    private void seteo(int idHospital) {
        this.hospital = HospitalDAO.getHospital(idHospital);
        idTxt.setText(String.valueOf(hospital.getIdHospital()));
        nombreTxt.setText(hospital.getNombre());
        direccionTxt.setText(hospital.getDireccion());
    }

    private boolean isValid(){
        this.alert = new Alert(Alert.AlertType.WARNING);
        this.alert.setHeaderText(null);
        this.alert.setTitle("Alerta");

        if (!nombreTxt.getText().isEmpty() && !direccionTxt.getText().isEmpty()) {
            return true;
        }

        alert.setContentText("No deje campos vacios");
        alert.show();
        return false;
    }
}

