package controller.editar;

import controller.gestion.GestionMedicoController;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import model.hospitales.Medico;
import service.hospitales.MedicoDAO;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;

public class EditarMedicosController {

    @FXML
    private Label Alerta;

    @FXML
    private TextField apellido1Txt;

    @FXML
    private TextField apellido2Txt;

    @FXML
    private Text cedulaTxt;

    @FXML
    private DatePicker fecNacimiento;

    @FXML
    private Label edadTxt;

    @FXML
    private TextField nombreTxt;
    private GestionMedicoController gestionMedicoController;
    private  ObservableList<Medico> observableMedico;
    private Medico medico;
    private Alert alert;

    @javafx.fxml.FXML
    public void initialize() {
        alert = new Alert(Alert.AlertType.WARNING);
        alert.setHeaderText(null);
        fecNacimiento.valueProperty().addListener((observable, oldValue, newValue) -> calcularEdad(newValue));
        fecNacimiento.setEditable(false);

    }
    @FXML
    void btnCancelarOnAction(ActionEvent event) {
        gestionMedicoController.stage.close();
    }

    @FXML
    void btnLimpiarOnAction(ActionEvent event) {
        apellido2Txt.setText("");
        fecNacimiento.setValue(null);
        edadTxt.setText("");
        nombreTxt.setText("");
        apellido1Txt.setText("");
        Alerta.setText("");
    }

    void seteos(int cedula){
        this.medico = MedicoDAO.getMedico(cedula);

        cedulaTxt.setText(medico.getCedula() + "");
        nombreTxt.setText(medico.getNombre());
        apellido1Txt.setText(medico.getApellido1());
        apellido2Txt.setText(medico.getApellido2());
        fecNacimiento.setValue(medico.getFecNacimiento().toLocalDate());

    }
    private void calcularEdad(LocalDate fechaNacimiento) {
        // Verifica si la fecha de nacimiento es válida
        if (fechaNacimiento != null) {
            // Calcula la edad usando la clase Period
            Period periodo = Period.between(fechaNacimiento, LocalDate.now());
            int edad = periodo.getYears();
            String ed = edad + "";

            // Actualiza el Label con la edad calculada
            edadTxt.setText(ed);
        } else {
            // Si la fecha de nacimiento es nula, muestra un mensaje indicando que la fecha es inválida
            edadTxt.setText("Fecha de nacimiento inválida");
        }
    }


    public void addController(GestionMedicoController gestionMedicoController, int cedula) {
        this.gestionMedicoController = gestionMedicoController;
        seteos(cedula);
    }
    private boolean isValid(){
        if (!apellido2Txt.getText().isEmpty() && fecNacimiento.getValue() != null && !edadTxt.getText().isEmpty()
                && !nombreTxt.getText().isEmpty() && !apellido1Txt.getText().isEmpty() && !cedulaTxt.getText().isEmpty())
        {
            return true;
        } else {
            alert.setContentText("Complete todos los campos");
            alert.show();
        }
        return false;
    }

    public void btnAgregarOnAction(ActionEvent actionEvent) {
        Medico medicoNuevo = new Medico();

        if (isValid()){
            medicoNuevo.setCedula(Integer.parseInt(cedulaTxt.getText()));
            medicoNuevo.setNombre(nombreTxt.getText());
            medicoNuevo.setApellido1(apellido1Txt.getText());
            medicoNuevo.setApellido2(apellido2Txt.getText());
            medicoNuevo.setFecNacimiento(Date.valueOf(fecNacimiento.getValue()));
            medicoNuevo.setEdad(Integer.parseInt(edadTxt.getText()));

            MedicoDAO.updateMedico(medicoNuevo);
            gestionMedicoController.seteo();
            gestionMedicoController.stage.close();
        }
    }
}