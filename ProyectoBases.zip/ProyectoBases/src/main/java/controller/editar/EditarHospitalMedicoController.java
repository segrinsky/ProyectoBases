package controller.editar;

import controller.gestion.GestionMedicoController;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.text.Text;
import javafx.util.converter.IntegerStringConverter;
import model.hospitales.HospitalMedico;
import model.hospitales.Medico;
import service.hospitales.HospitalMedicoDAO;

public class EditarHospitalMedicoController {

    @FXML
    private Label Alerta;

    @FXML
    private Text cedulaTxt;

    @FXML
    private TextField idHospitalTxt;
    private Alert alert;

    GestionMedicoController gestionMedicoController;
    ObservableList<Medico> observablePacientesMedico;
    ObservableList<HospitalMedico> observableListHospi;
    HospitalMedico hospitalMedico;

    @FXML
    void btnAgregarOnAction(ActionEvent event) {
        if (isValid()){
            int id = Integer.parseInt(idHospitalTxt.getText());
            HospitalMedicoDAO.updateHospitalMedico(hospitalMedico, id);
            gestionMedicoController.seteo();
            gestionMedicoController.stage.close();
        }
    }

    @FXML
    void btnCancelarOnAction(ActionEvent event) {
        gestionMedicoController.stage.close();
    }

    @FXML
    void btnLimpiarOnAction(ActionEvent event) {
        idHospitalTxt.setText("");

    }

    public void addController(GestionMedicoController gestionUsuariosController, int idHospital, int cedula) {
        this.gestionMedicoController = gestionUsuariosController;
        seteo(idHospital, cedula);
        numerosSolo();
    }
    public void numerosSolo() {
        TextFormatter<Integer> textFormatter = new TextFormatter<>(new IntegerStringConverter(), null);
        idHospitalTxt.setTextFormatter(textFormatter);

        textFormatter.valueProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue == null) {
                idHospitalTxt.setText("");
            }
        });

        idHospitalTxt.textProperty().addListener((obs, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                idHospitalTxt.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }
    private void seteo(int idHospital, int cedula) {
        hospitalMedico = HospitalMedicoDAO.getHospitalMedico(idHospital, cedula);
        cedulaTxt.setText(String.valueOf(hospitalMedico.getCedula()));
        idHospitalTxt.setText(String.valueOf(hospitalMedico.getIdHospital()));
    }
    private boolean isValid(){
        this.alert = new Alert(Alert.AlertType.WARNING);
        this.alert.setHeaderText(null);
        this.alert.setTitle("Alerta");

        if (!cedulaTxt.getText().isEmpty() && !idHospitalTxt.getText().isEmpty()) {
            int cedulaBuscada = Integer.parseInt(cedulaTxt.getText());
            int idBuscado = Integer.parseInt(idHospitalTxt.getText());
            boolean registerExist = HospitalMedicoDAO.registerExist(cedulaBuscada, idBuscado);

            if (registerExist){
                alert.setContentText("No se puede dejar el registro de igual manera");
                alert.show();
            } else {
                return true;
            }

        }
        return false;
    }
}
