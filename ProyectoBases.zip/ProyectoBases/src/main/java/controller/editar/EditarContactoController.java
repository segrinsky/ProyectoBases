package controller.editar;

import controller.gestion.GestionStockController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.text.Text;
import javafx.util.converter.IntegerStringConverter;
import model.hospitales.TelefonosPaciente;
import service.hospitales.TelefonosPacienteDAO;

public class EditarContactoController {

    private Alert alert;

    @FXML
    private Text cedulaTxt;

    @FXML
    private TextField telefonoTxt;

    GestionStockController gestionUsuariosController;
    TelefonosPaciente pacienteTelefono;

    @FXML
    void btnAgregarOnAction(ActionEvent event) {
        if (isValid()){
            TelefonosPacienteDAO.updateTelefonoPaciente(pacienteTelefono, Integer.parseInt(telefonoTxt.getText()));
//            gestionUsuariosController.seteo();
            gestionUsuariosController.stage.close();
        }
    }

    @FXML
    void btnCancelarOnAction(ActionEvent event) {
        gestionUsuariosController.stage.close();
    }

    @FXML
    void btnLimpiarOnAction(ActionEvent event) {
        telefonoTxt.setText("");

    }

    public void addController(GestionStockController gestionUsuariosController, int cedula, int telefono) {
        this.gestionUsuariosController = gestionUsuariosController;
        seteo(cedula, telefono);
        numerosSolo();
    }
    public void numerosSolo() {
        TextFormatter<Integer> textFormatter = new TextFormatter<>(new IntegerStringConverter(), null);
        telefonoTxt.setTextFormatter(textFormatter);

        textFormatter.valueProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue == null) {
                telefonoTxt.setText("");
            }
        });

        telefonoTxt.textProperty().addListener((obs, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                telefonoTxt.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }
    private void seteo(int cedula, int telefono) {
        this.pacienteTelefono = TelefonosPacienteDAO.getTelefonoPaciente(cedula, telefono);
        cedulaTxt.setText(String.valueOf(pacienteTelefono.getCedula()));
        telefonoTxt.setText(String.valueOf(pacienteTelefono.getTelefono()));
    }
    private boolean isValid(){
        this.alert = new Alert(Alert.AlertType.WARNING);
        this.alert.setHeaderText(null);
        this.alert.setTitle("Alerta");

        if (!cedulaTxt.getText().isEmpty() && !telefonoTxt.getText().isEmpty()) {
            int cedulaBuscada = Integer.parseInt(cedulaTxt.getText());
            int telefonoBuscado = Integer.parseInt(telefonoTxt.getText());
            boolean registerExist = TelefonosPacienteDAO.registerExist(cedulaBuscada, telefonoBuscado);

            if (registerExist){
                alert.setContentText("No se puede dejar el registro de igual manera");
                alert.show();
            } else if (telefonoTxt.getText().length() != 8) {
                alert.setContentText("Ingresa un telefono válido");
                alert.show();
            }else {
                return true;
            }

        }
        return false;
    }


}
