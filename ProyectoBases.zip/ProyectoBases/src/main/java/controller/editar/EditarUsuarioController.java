package controller.editar;

import controller.gestion.GestionStockController;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import model.hospitales.Paciente;
import service.hospitales.PacienteDAO;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;

public class EditarUsuarioController {

    @FXML
    private Label Alerta;

    @FXML
    private TextField apellido1Txt;

    @FXML
    private TextField apellido2Txt;

    @FXML
    private Text cedulaTxt;

    @FXML
    private DatePicker fecNacimiento;

    @FXML
    private Label edadTxt;

    @FXML
    private TextField nombreTxt;
    private GestionStockController gestionUsuariosController;
    private  ObservableList<Paciente> observablePaciente;
    private Paciente paciente;
    private Alert alert;

    @FXML
    public void initialize() {
        alert = new Alert(Alert.AlertType.WARNING);
        alert.setHeaderText(null);
        fecNacimiento.valueProperty().addListener((observable, oldValue, newValue) -> calcularEdad(newValue));
        fecNacimiento.setEditable(false);
    }
    @FXML
    void btnCancelarOnAction(ActionEvent event) {
        gestionUsuariosController.stage.close();
    }

    @FXML
    void btnLimpiarOnAction(ActionEvent event) {
            apellido2Txt.setText("");
            fecNacimiento.setValue(null);
            edadTxt.setText("");
            nombreTxt.setText("");
            apellido1Txt.setText("");
            Alerta.setText("");
    }

    void seteos(int cedula){
        this.paciente = PacienteDAO.getPaciente(cedula);
        cedulaTxt.setText(String.valueOf(paciente.getCedula()));
        nombreTxt.setText(paciente.getNombre());
        apellido1Txt.setText(paciente.getApellido1());
        apellido2Txt.setText(paciente.getApellido2());
        fecNacimiento.setValue(paciente.getFecNacimiento().toLocalDate());
    }
    private void calcularEdad(LocalDate fechaNacimiento) {
        // Verifica si la fecha de nacimiento es válida
        if (fechaNacimiento != null) {
            // Calcula la edad usando la clase Period
            Period periodo = Period.between(fechaNacimiento, LocalDate.now());
            int edad = periodo.getYears();
            String ed = edad + "";

            // Actualiza el Label con la edad calculada
            edadTxt.setText(ed);
        } else {
            // Si la fecha de nacimiento es nula, muestra un mensaje indicando que la fecha es inválida
            edadTxt.setText("Fecha de nacimiento inválida");
        }
    }
    @FXML
    void btnModificarOnAction(ActionEvent event) {
        Paciente pacienteNuevo = new Paciente();

        if (isValid()){
            pacienteNuevo.setCedula(Integer.parseInt(cedulaTxt.getText()));
            pacienteNuevo.setNombre(nombreTxt.getText());
            pacienteNuevo.setApellido1(apellido1Txt.getText());
            pacienteNuevo.setApellido2(apellido2Txt.getText());
            pacienteNuevo.setFecNacimiento(Date.valueOf(fecNacimiento.getValue()));
            pacienteNuevo.setEdad(Integer.parseInt(edadTxt.getText()));

            PacienteDAO.updatePaciente(pacienteNuevo);
//            gestionUsuariosController.seteo();
            gestionUsuariosController.stage.close();
        }
    }

    public void addController(GestionStockController gestionUsuariosController, int cedula) {
        this.gestionUsuariosController = gestionUsuariosController;
        seteos(cedula);
    }
    private boolean isValid(){
        if (!apellido2Txt.getText().isEmpty() && fecNacimiento.getValue() != null && !edadTxt.getText().isEmpty()
                && !nombreTxt.getText().isEmpty() && !apellido1Txt.getText().isEmpty() && !cedulaTxt.getText().isEmpty()) {

            return true;

        } else {
            alert.setContentText("Complete todos los campos");
            alert.show();
        }
        return false;
    }
}