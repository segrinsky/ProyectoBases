package controller.gestion;

import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.util.Callback;
import service.hospitales.HospitalDAO;
import service.hospitales.HospitalMedicoDAO;
import ucr.proyectobases.HelloApplication;
import controller.agregar.AgregarHospitalController;
import controller.editar.EditarHospitalController;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import model.hospitales.Hospital;

import java.io.IOException;
import java.util.Optional;

public class GestionHospitalesController {

    @FXML
    private Button bbtnModificar;

    @FXML
    private BorderPane bp;
    @FXML
    private TableColumn<Hospital, String> editCol;


    @FXML
    private Button btnoEliminar;
    public Stage stage = new Stage();

    @FXML
    private TableColumn<Hospital, String> direccionColumn;

    @FXML
    private TableColumn<Hospital, Integer> idColumn;

    @FXML
    private TableColumn<Hospital, String> nombreColumn;
    AgregarHospitalController agregarHospitalController;
    EditarHospitalController editarHospitalControler;

    @FXML
    private StackPane stackPane;

    @FXML
    private TableView<Hospital> tblViewHospitales;
    private Alert qAlert;

    @javafx.fxml.FXML
    public void initialize() {
        qAlert = new Alert(Alert.AlertType.CONFIRMATION);
        qAlert.setHeaderText(null);
        stackPane.getChildren().setAll(tblViewHospitales);
        seteoInicial();
    }

    private void seteoInicial() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("idHospital"));

        nombreColumn.setCellValueFactory(new PropertyValueFactory<>("nombre"));

        direccionColumn.setCellValueFactory(new PropertyValueFactory<>("direccion"));

        Callback<TableColumn<Hospital, String>, TableCell<Hospital, String>> cellFactory = (TableColumn<Hospital, String> param) -> {
            // make cell containing buttons
            final TableCell<Hospital, String> cell = new TableCell<Hospital, String>() {
                @Override
                public void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    // esa celda se crea solo en filas no vacías
                    if (empty) {
                        setGraphic(null);
                        setText(null);
                    } else {
                        // Usa imágenes en lugar de texto
                        ImageView deleteIcon = new ImageView(new Image(getClass().getResourceAsStream("/Trash Can.png")));
                        ImageView editIcon = new ImageView(new Image(getClass().getResourceAsStream("/Edit.png")));

                        deleteIcon.setCursor(Cursor.HAND);
                        editIcon.setCursor(Cursor.HAND);

                        deleteIcon.setFitWidth(30);
                        deleteIcon.setFitHeight(30);

                        editIcon.setFitWidth(30);
                        editIcon.setFitHeight(30);

                        deleteIcon.setOnMouseClicked((MouseEvent event) -> btnEliminarOnAction());
                        editIcon.setOnMouseClicked((MouseEvent event) -> btnModificarOnAction());

                        HBox manageBtn = new HBox(editIcon, deleteIcon);
                        manageBtn.setStyle("-fx-alignment:center");
                        manageBtn.setSpacing(5);
                        HBox.setMargin(deleteIcon, new Insets(2, 2, 0, 3));
                        HBox.setMargin(editIcon, new Insets(2, 3, 0, 2));

                        setGraphic(manageBtn);
                        setText(null);
                    }
                }
            };

            return cell;
        };
        editCol.setCellFactory(cellFactory);
        // Establecer los datos en las TableViews
        tblViewHospitales.setItems(FXCollections.observableArrayList(HospitalDAO.obtenerHospital()));
    }
    private void loadPage(String page) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource(page));
        try {
            stage.setScene(new Scene(fxmlLoader.load()));
            stage.setResizable(false);
            stage.show();

            if (page.contains("agregar")) {
                agregarHospitalController = fxmlLoader.getController();
            }else if (page.contains("editar")){
                editarHospitalControler = fxmlLoader.getController();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    void btnAgregarOnAction(ActionEvent event) {
        loadPage("agregarHospital.fxml");
        agregarHospitalController.loadController(this);
    }


    void btnEliminarOnAction() {

        qAlert.setTitle("Confirmacion");
        qAlert.setContentText("Seguro que quieres eliminar este registro?");

        ButtonType buttonTypeAceptar = new ButtonType("Aceptar");
        ButtonType buttonTypeCancelar = new ButtonType("Cancelar");

        qAlert.getButtonTypes().setAll(buttonTypeAceptar, buttonTypeCancelar);

        // Mostrar el Alert y obtener la respuesta del usuario
        Optional<ButtonType> result = qAlert.showAndWait();

        // Procesar la respuesta del usuario
        if (result.isPresent() && result.get() == buttonTypeAceptar) {
            if (tblViewHospitales.getSelectionModel().getSelectedItem() != null) {
                int idHospital = tblViewHospitales.getSelectionModel().getSelectedItem().getIdHospital();
                HospitalMedicoDAO.deleteAllHospital(idHospital);
                HospitalDAO.deleteHospital(idHospital);
                seteo();
            }
        }
    }


    void btnModificarOnAction() {
        if (tblViewHospitales.getSelectionModel().getSelectedItem() != null){
            loadPage("editarHospital.fxml");
            editarHospitalControler.loadController(this, tblViewHospitales.getSelectionModel().getSelectedItem().getIdHospital());
        }

    }

    public void seteo(){
        tblViewHospitales.setItems(FXCollections.observableArrayList(HospitalDAO.obtenerHospital()));
    }

}
