package controller.gestion;

import controller.agregar.AgregarContactoController;
import controller.agregar.AgregarUsuarioController;
import controller.agregar.AgregarVehiculoController;
import controller.editar.EditarContactoController;
import controller.editar.EditarUsuarioController;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.util.Callback;
import model.Vehiculo;
import service.VehiculosDAO;
import ucr.proyectobases.HelloApplication;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import model.hospitales.TelefonosPaciente;
import model.hospitales.Paciente;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;


public class GestionStockController
{
    @javafx.fxml.FXML
    private TableView<Vehiculo> tblviewVehiculos;
    @javafx.fxml.FXML
    private BorderPane bp;
    @FXML
    private TableColumn<Vehiculo, Integer> idColumn;

    @FXML
    private TableColumn<Vehiculo, Integer> tipoColumn;

    @FXML
    private TableColumn<Vehiculo, Integer> estiloColumn;

    @FXML
    private TableColumn<Vehiculo, String> descColumn;

    @FXML
    private TableColumn<Vehiculo, String> añoColumn;

    @FXML
    private TableColumn<Vehiculo, Double> precioColumn;

    @FXML
    private TableColumn<Vehiculo, String> editColC;

    @FXML
    private ChoiceBox<String> cbxEstilo;

    @FXML
    private ChoiceBox<String> cbxTipo;

    @FXML
    private TextField maximoTxt;

    @FXML
    private TextField minimoTxt;

    @FXML
    private TextField textAño;
    private Alert alert;
    private Alert qAlert;
    public Stage stage = new Stage();
    public AgregarVehiculoController agregarVehiculoController = new AgregarVehiculoController();
    public EditarUsuarioController editarUsuarioController = new EditarUsuarioController();
    private EditarContactoController editarContactoController = new EditarContactoController();

    @javafx.fxml.FXML
    public void initialize() {
        alert = new Alert(Alert.AlertType.WARNING);
        qAlert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        qAlert.setHeaderText(null);
        cbxEstilo.getItems().addAll();
        autoFill();
        seteoInicial();
    }

    public void autoFill(){
        List<Vehiculo> vehiculos = VehiculosDAO.obtenerVehiculos();
        Set<String> tiposVehiculos = vehiculos.stream()
                .map(Vehiculo::getTipoVehiculo)
                .collect(Collectors.toSet());
        cbxTipo.getItems().addAll(tiposVehiculos);
        System.out.println(vehiculos);
        Set<String> estilo = vehiculos.stream()
                .map(Vehiculo::getEstilo)
                .collect(Collectors.toSet());
        cbxEstilo.getItems().addAll(estilo);
    }

//    public void seteo() {
//        if (cbxOpcion.getValue() == "Pacientes"){
//            stackPane.getChildren().setAll(tblViewPacientes);
//            tblViewPacientes.setItems(FXCollections.observableArrayList(PacienteDAO.obtenerPacientes()));
//        } else if (cbxOpcion.getValue() == "Contactos") {
//            stackPane.getChildren().setAll(tblviewVehiculos);
//            tblviewVehiculos.setItems(FXCollections.observableArrayList(TelefonosPacienteDAO.obtenerTelefonoPaciente()));
//        }
//    }

    private void seteoInicial() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("idVehiculo"));
        tipoColumn.setCellValueFactory(new PropertyValueFactory<>("tipoVehiculo"));
        estiloColumn.setCellValueFactory(new PropertyValueFactory<>("estilo"));
        descColumn.setCellValueFactory(new PropertyValueFactory<>("descripcion"));
        añoColumn.setCellValueFactory(new PropertyValueFactory<>("anoFabricacion"));
        precioColumn.setCellValueFactory(new PropertyValueFactory<>("precio"));

        // Si necesitas una columna para botones de edición o eliminación, puedes agregar una celda personalizada aquí
         editColC.setCellFactory(pacienteColumn());

        tblviewVehiculos.setItems(FXCollections.observableArrayList(VehiculosDAO.obtenerVehiculos()));
    }

    private void loadPage(String page) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource(page));
        try {
            stage = new Stage();
            stage.setScene(new Scene(fxmlLoader.load()));
            stage.setResizable(false);
            stage.show();

            if (page.contains("agregarVehiculo")) {
                agregarVehiculoController = fxmlLoader.getController();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void btnEliminarOnAction() {
//        qAlert.setTitle("Confirmacion");
//        qAlert.setContentText("Seguro que quieres eliminar este registro?");
//
//        ButtonType buttonTypeAceptar = new ButtonType("Aceptar");
//        ButtonType buttonTypeCancelar = new ButtonType("Cancelar");
//
//        qAlert.getButtonTypes().setAll(buttonTypeAceptar, buttonTypeCancelar);
//
//        // Mostrar el Alert y obtener la respuesta del usuario
//        Optional<ButtonType> result = qAlert.showAndWait();
//
//        // Procesar la respuesta del usuario
//        if (result.isPresent() && result.get() == buttonTypeAceptar) {
//            if (cbxOpcion.getValue() == "Pacientes"){
//                int cedula = tblViewPacientes.getSelectionModel().getSelectedItem().getCedula();
//                TelefonosPacienteDAO.deleteAll(cedula);
//                PacienteDAO.deletePaciente(cedula);
//                seteo();
//            }else if (cbxOpcion.getValue() == "Contactos"){
//                TelefonosPaciente telefonoBorrado = tblviewVehiculos.getSelectionModel().getSelectedItem();
//                TelefonosPacienteDAO.deleteTelefonoPaciente(telefonoBorrado.getCedula(), telefonoBorrado.getTelefono());
//            }
//            seteo();
//        }

    }

    @javafx.fxml.FXML
    public void btnAgregarOnAction(ActionEvent actionEvent) {
        loadPage("agregarVehiculo.fxml");
        agregarVehiculoController.addController(this);
    }

    public void btnModificarOnAction() {
//        if (cbxOpcion.getValue() == "Pacientes" && tblViewPacientes.getSelectionModel().getSelectedItem() != null){
//            int cedula = tblViewPacientes.getSelectionModel().getSelectedItem().getCedula();
//            loadPage("editarUsuarios.fxml");
//            editarUsuarioController.addController(this, cedula);
//        }else if (cbxOpcion.getValue() == "Contactos" && tblviewVehiculos.getSelectionModel().getSelectedItem() != null){
//            int cedula = tblviewVehiculos.getSelectionModel().getSelectedItem().getCedula();
//            int telefono = tblviewVehiculos.getSelectionModel().getSelectedItem().getTelefono();
//            loadPage("editarContacto.fxml");
//            editarContactoController.addController(this, cedula, telefono);
//        }
    }

    public Callback<TableColumn<Vehiculo, String>, TableCell<Vehiculo, String>> pacienteColumn(){
        Callback<TableColumn<Vehiculo, String>, TableCell<Vehiculo, String>> cellFactory = (TableColumn<Vehiculo, String> param) -> {
            // make cell containing buttons
            final TableCell<Vehiculo, String> cell = new TableCell<Vehiculo, String>() {
                @Override
                public void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    // esa celda se crea solo en filas no vacías
                    if (empty) {
                        setGraphic(null);
                        setText(null);
                    } else {
                        // Usa imágenes en lugar de texto
                        ImageView deleteIcon = new ImageView(new Image(getClass().getResourceAsStream("/Trash Can.png")));
                        ImageView editIcon = new ImageView(new Image(getClass().getResourceAsStream("/Edit.png")));

                        deleteIcon.setCursor(Cursor.HAND);
                        editIcon.setCursor(Cursor.HAND);

                        deleteIcon.setFitWidth(30);
                        deleteIcon.setFitHeight(30);

                        editIcon.setFitWidth(30);
                        editIcon.setFitHeight(30);

                        deleteIcon.setOnMouseClicked((MouseEvent event) -> btnEliminarOnAction());
                        editIcon.setOnMouseClicked((MouseEvent event) -> btnModificarOnAction());

                        HBox manageBtn = new HBox(editIcon, deleteIcon);
                        manageBtn.setStyle("-fx-alignment:center");
                        manageBtn.setSpacing(5);
                        HBox.setMargin(deleteIcon, new Insets(2, 2, 0, 3));
                        HBox.setMargin(editIcon, new Insets(2, 3, 0, 2));

                        setGraphic(manageBtn);
                        setText(null);
                    }
                }
            };

            return cell;
        };

        return cellFactory;
    }

    public Callback<TableColumn<TelefonosPaciente, String>, TableCell<TelefonosPaciente, String>> telefonosPacienteColumn(){
        Callback<TableColumn<TelefonosPaciente, String>, TableCell<TelefonosPaciente, String>> cellFactory = (TableColumn<TelefonosPaciente, String> param) -> {
            // make cell containing buttons
            final TableCell<TelefonosPaciente, String> cell = new TableCell<TelefonosPaciente, String>() {
                @Override
                public void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    // esa celda se crea solo en filas no vacías
                    if (empty) {
                        setGraphic(null);
                        setText(null);
                    } else {
                        // Usa imágenes en lugar de texto
                        ImageView deleteIcon = new ImageView(new Image(getClass().getResourceAsStream("/Trash Can.png")));
                        ImageView editIcon = new ImageView(new Image(getClass().getResourceAsStream("/Edit.png")));

                        deleteIcon.setCursor(Cursor.HAND);
                        editIcon.setCursor(Cursor.HAND);

                        deleteIcon.setFitWidth(30);
                        deleteIcon.setFitHeight(30);

                        editIcon.setFitWidth(30);
                        editIcon.setFitHeight(30);

                        deleteIcon.setOnMouseClicked((MouseEvent event) -> btnEliminarOnAction());
                        editIcon.setOnMouseClicked((MouseEvent event) -> btnModificarOnAction());

                        HBox manageBtn = new HBox(editIcon, deleteIcon);
                        manageBtn.setStyle("-fx-alignment:center");
                        manageBtn.setSpacing(5);
                        HBox.setMargin(deleteIcon, new Insets(2, 2, 0, 3));
                        HBox.setMargin(editIcon, new Insets(2, 3, 0, 2));

                        setGraphic(manageBtn);
                        setText(null);
                    }
                }
            };

            return cell;
        };

        return cellFactory;
    }

    public void btnReporteOnAction(ActionEvent actionEvent) {
    }

    public void btnAplicarOnAction(ActionEvent actionEvent) {
    }
}