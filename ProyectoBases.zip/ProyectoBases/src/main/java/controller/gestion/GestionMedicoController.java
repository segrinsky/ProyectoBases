package controller.gestion;

import controller.editar.EditarHospitalMedicoController;
import controller.editar.EditarMedicosController;
import controller.agregar.AgregarHospitalMedicoController;
import controller.agregar.AgregarVehiculoController;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.util.Callback;
import model.hospitales.HospitalMedico;
import model.hospitales.Medico;
import service.hospitales.HospitalMedicoDAO;
import service.hospitales.MedicoDAO;
import ucr.proyectobases.HelloApplication;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Optional;

public class GestionMedicoController {

    @FXML
    private TableColumn<Medico, String> apellido1ColumnMedico;

    @FXML
    private TableColumn<Medico, String> apellido2ColumnMedico;

    @FXML
    private Button bbtnModificar;

    @FXML
    private BorderPane bp;

    @FXML
    private Button btnoEliminar;

    @FXML
    private TableColumn<HospitalMedico, Integer> cedulaColumnHospital;

    @FXML
    private TableColumn<Medico, Integer> cedulaColumnMedico;

    @FXML
    private ChoiceBox<String> cbxOpcion;

    @FXML
    private TableColumn<Medico, Integer> edadColumn;

    @FXML
    private TableColumn<Medico, LocalDate> fec_NacimientoColumn;

    @FXML
    private TableColumn<HospitalMedico, Integer> hospitalColumn;
    @FXML
    private TableColumn<Medico, String> editCol;

    @FXML
    private TableColumn<HospitalMedico, String> editColH;

    @FXML
    private TableColumn<Medico, String> nombreColumnMedico;

    public Stage stage = new Stage();
    private Alert qAlert;

    AgregarVehiculoController agregarMedicoController;
    EditarMedicosController editarMedicoController;
    AgregarHospitalMedicoController agregarHospital_MedicoController;
    EditarHospitalMedicoController editarHospitalMedicoController;
    @FXML
    private StackPane stackPane;

    @FXML
    private TableView<HospitalMedico> tblViewHospital_Medico;

    @FXML
    private TableView<Medico> tblViewMedico;
    @javafx.fxml.FXML
    public void initialize() {
        qAlert = new Alert(Alert.AlertType.CONFIRMATION);
        qAlert.setHeaderText(null);
        cbxOpcion.getItems().addAll("Médicos", "Hospital-Médico");
        stackPane.getChildren().setAll(tblViewMedico);
        cbxOpcion.setOnAction(event -> seteo());
        seteoInicial();
        cbxOpcion.getSelectionModel().selectFirst();
    }

    public void seteo() {
        if (cbxOpcion.getValue() == "Médicos"){
            stackPane.getChildren().setAll(tblViewMedico);
            tblViewMedico.setItems(FXCollections.observableArrayList(MedicoDAO.obtenerMedico()));
        } else if (cbxOpcion.getValue() == "Hospital-Médico") {
            stackPane.getChildren().setAll(tblViewHospital_Medico);
            tblViewHospital_Medico.setItems(FXCollections.observableArrayList(HospitalMedicoDAO.obtenerHospitalMedico()));

        }
    }

    private void seteoInicial() {

        cedulaColumnHospital.setCellValueFactory(new PropertyValueFactory<>("cedula"));
        cedulaColumnMedico.setCellValueFactory(new PropertyValueFactory<>("cedula"));


        nombreColumnMedico.setCellValueFactory(new PropertyValueFactory<>("nombre"));


        apellido1ColumnMedico.setCellValueFactory(new PropertyValueFactory<>("apellido1"));

        apellido2ColumnMedico.setCellValueFactory(new PropertyValueFactory<>("apellido2"));

        fec_NacimientoColumn.setCellValueFactory(new PropertyValueFactory<>("fecNacimiento"));

        edadColumn.setCellValueFactory(new PropertyValueFactory<>("edad"));

        hospitalColumn.setCellValueFactory(new PropertyValueFactory<>("idHospital"));

        editCol.setCellFactory(medicoColumn());
        editColH.setCellFactory(hospitalMedicoColumn());

        // Establecer los datos en las TableViews
        tblViewMedico.setItems(FXCollections.observableArrayList(MedicoDAO.obtenerMedico()));
        tblViewHospital_Medico.setItems(FXCollections.observableArrayList(HospitalMedicoDAO.obtenerHospitalMedico()));
    }
    private void loadPage(String page) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource(page));
        try {
            stage = new Stage();
            stage.setScene(new Scene(fxmlLoader.load()));
            stage.setResizable(false);
            stage.show();

            if (page.contains("agregarMedico")) {
                agregarMedicoController = fxmlLoader.getController();
            } else if (page.contains("agregarHospital")) {
                agregarHospital_MedicoController = fxmlLoader.getController();
            } else if (page.contains("editarMedico")){
                editarMedicoController = fxmlLoader.getController();
            }else if (page.contains("editarHospital")){
                editarHospitalMedicoController = fxmlLoader.getController();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    void btnModificarOnAction() {
        if (cbxOpcion.getValue() == "Médicos" && tblViewMedico.getSelectionModel().getSelectedItem() != null){
            int cedula = tblViewMedico.getSelectionModel().getSelectedItem().getCedula();
            loadPage("editarMedicos.fxml");
            editarMedicoController.addController(this, cedula);
        } else if (cbxOpcion.getValue() == "Hospital-Médico" && tblViewHospital_Medico.getSelectionModel().getSelectedItem() != null) {
            loadPage("editarHospital_Medico.fxml" );
            int cedula = tblViewHospital_Medico.getSelectionModel().getSelectedItem().getCedula();
            int idHospital = tblViewHospital_Medico.getSelectionModel().getSelectedItem().getIdHospital();
            editarHospitalMedicoController.addController(this, idHospital, cedula);
        }
    }
    @FXML
    void btnAgregarOnAction(ActionEvent event) {
        if (cbxOpcion.getValue() == "Médicos"){
            loadPage("agregarVehiculo.fxml");
//            agregarMedicoController.addController(this);
        }
    }

    void btnEliminarOnAction() {
        qAlert.setTitle("Confirmacion");
        qAlert.setContentText("Seguro que quieres eliminar este registro?");

        ButtonType buttonTypeAceptar = new ButtonType("Aceptar");
        ButtonType buttonTypeCancelar = new ButtonType("Cancelar");

        qAlert.getButtonTypes().setAll(buttonTypeAceptar, buttonTypeCancelar);

        // Mostrar el Alert y obtener la respuesta del usuario
        Optional<ButtonType> result = qAlert.showAndWait();

        // Procesar la respuesta del usuario
        if (result.isPresent() && result.get() == buttonTypeAceptar) {
            if (cbxOpcion.getValue() == "Médicos") {
                int cedula = tblViewMedico.getSelectionModel().getSelectedItem().getCedula();
                HospitalMedicoDAO.deleteAllMedico(cedula);
                MedicoDAO.deleteMedico(cedula);
            } else if (cbxOpcion.getValue() == "Hospital-Médico") {
                HospitalMedico hospitalMedico = tblViewHospital_Medico.getSelectionModel().getSelectedItem();
                HospitalMedicoDAO.deleteHospitalMedico(hospitalMedico.getIdHospital(), hospitalMedico.getCedula());
            }
            seteo();
        }
    }

    public Callback<TableColumn<Medico, String>, TableCell<Medico, String>> medicoColumn(){
        Callback<TableColumn<Medico, String>, TableCell<Medico, String>> cellFactory = (TableColumn<Medico, String> param) -> {
            // make cell containing buttons
            final TableCell<Medico, String> cell = new TableCell<Medico, String>() {
                @Override
                public void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    // esa celda se crea solo en filas no vacías
                    if (empty) {
                        setGraphic(null);
                        setText(null);
                    } else {
                        // Usa imágenes en lugar de texto
                        ImageView deleteIcon = new ImageView(new Image(getClass().getResourceAsStream("/Trash Can.png")));
                        ImageView editIcon = new ImageView(new Image(getClass().getResourceAsStream("/Edit.png")));

                        deleteIcon.setCursor(Cursor.HAND);
                        editIcon.setCursor(Cursor.HAND);

                        deleteIcon.setFitWidth(30);
                        deleteIcon.setFitHeight(30);

                        editIcon.setFitWidth(30);
                        editIcon.setFitHeight(30);

                        deleteIcon.setOnMouseClicked((MouseEvent event) -> btnEliminarOnAction());
                        editIcon.setOnMouseClicked((MouseEvent event) -> btnModificarOnAction());

                        HBox manageBtn = new HBox(editIcon, deleteIcon);
                        manageBtn.setStyle("-fx-alignment:center");
                        manageBtn.setSpacing(5);
                        HBox.setMargin(deleteIcon, new Insets(2, 2, 0, 3));
                        HBox.setMargin(editIcon, new Insets(2, 3, 0, 2));

                        setGraphic(manageBtn);
                        setText(null);
                    }
                }
            };

            return cell;
        };

        return cellFactory;
    }

    public Callback<TableColumn<HospitalMedico, String>, TableCell<HospitalMedico, String>> hospitalMedicoColumn(){
        Callback<TableColumn<HospitalMedico, String>, TableCell<HospitalMedico, String>> cellFactory = (TableColumn<HospitalMedico, String> param) -> {
            // make cell containing buttons
            final TableCell<HospitalMedico, String> cell = new TableCell<HospitalMedico, String>() {
                @Override
                public void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    // esa celda se crea solo en filas no vacías
                    if (empty) {
                        setGraphic(null);
                        setText(null);
                    } else {
                        // Usa imágenes en lugar de texto
                        ImageView deleteIcon = new ImageView(new Image(getClass().getResourceAsStream("/Trash Can.png")));
                        ImageView editIcon = new ImageView(new Image(getClass().getResourceAsStream("/Edit.png")));

                        deleteIcon.setCursor(Cursor.HAND);
                        editIcon.setCursor(Cursor.HAND);

                        deleteIcon.setFitWidth(30);
                        deleteIcon.setFitHeight(30);

                        editIcon.setFitWidth(30);
                        editIcon.setFitHeight(30);

                        deleteIcon.setOnMouseClicked((MouseEvent event) -> btnEliminarOnAction());
                        editIcon.setOnMouseClicked((MouseEvent event) -> btnModificarOnAction());

                        HBox manageBtn = new HBox(editIcon, deleteIcon);
                        manageBtn.setStyle("-fx-alignment:center");
                        manageBtn.setSpacing(5);
                        HBox.setMargin(deleteIcon, new Insets(2, 2, 0, 3));
                        HBox.setMargin(editIcon, new Insets(2, 3, 0, 2));

                        setGraphic(manageBtn);
                        setText(null);
                    }
                }
            };

            return cell;
        };

        return cellFactory;
    }

}
