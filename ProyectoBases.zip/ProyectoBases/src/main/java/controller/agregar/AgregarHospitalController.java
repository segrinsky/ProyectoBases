package controller.agregar;

import controller.gestion.GestionHospitalesController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import model.hospitales.Hospital;
import service.hospitales.HospitalDAO;

public class AgregarHospitalController {

    @FXML
    private Label Alerta;

    @FXML
    private TextField direccionTxt;

    private Alert alert;


    @FXML
    private TextField nombreTxt;
    GestionHospitalesController gestionHospitalesController;

    @FXML
    void btnAgregarOnAction(ActionEvent event) {
        if (isValid()){
            Hospital hospital = new Hospital(nombreTxt.getText(), direccionTxt.getText());
            HospitalDAO.insertHospital(hospital);
            gestionHospitalesController.seteo();
            gestionHospitalesController.stage.close();
        }
    }

    @FXML
    void btnCancelarOnAction(ActionEvent event) {
        gestionHospitalesController.stage.close();
    }

    @FXML
    void btnLimpiarOnAction(ActionEvent event) {

        nombreTxt.setText("");
        direccionTxt.setText("");
        Alerta.setText("");
    }

    public void loadController(GestionHospitalesController gestionHospitalesController) {
        this.gestionHospitalesController = gestionHospitalesController;
    }
    private boolean isValid(){
        this.alert = new Alert(Alert.AlertType.WARNING);
        this.alert.setHeaderText(null);
        this.alert.setTitle("Alerta");

        if (!nombreTxt.getText().isEmpty() && !direccionTxt.getText().isEmpty()) {
            return true;
        }

        alert.setContentText("No deje campos vacios");
        alert.show();
        return false;
    }
}

