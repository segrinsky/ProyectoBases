package controller.agregar;

import controller.gestion.GestionStockController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.util.converter.IntegerStringConverter;
import model.Estilo;
import model.TipoVehiculo;
import model.Transmision;
import model.hospitales.Medico;
import service.VehiculosDAO;
import service.hospitales.MedicoDAO;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;

public class AgregarVehiculoController {

    @FXML
    private Label Alerta;
    private Alert alert;

    @FXML
    private ChoiceBox<Object> tipoCbx;

    @FXML
    private Spinner<Integer> añoTxt;

    @FXML
    private ChoiceBox<String> cantidadPuertasCbx;
    @FXML
    private Spinner<Integer> cantidadTxt;

    @FXML
    private TextArea descTxt;

    @FXML
    private ChoiceBox<Object> estiloCbx;

    @FXML
    private TextField idTxt;

    @FXML
    private TextField precioTxt;

    @FXML
    private ChoiceBox<Object> transCbx;
    SpinnerValueFactory.IntegerSpinnerValueFactory añoValue = new SpinnerValueFactory.IntegerSpinnerValueFactory(1918, 3000, 2024);
    SpinnerValueFactory.IntegerSpinnerValueFactory cantidad = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 100, 1);
    @FXML
    private TextField nombreTxt;
    private GestionStockController gestionStockController;

    @FXML
    public void initialize() {
        this.alert = new Alert(Alert.AlertType.WARNING);
        this.alert.setHeaderText(null);
        this.alert.setTitle("Alerta");

        List<Transmision> transmisiones = VehiculosDAO.obtenerTransmisiones();
        transCbx.getItems().add("-");
        transCbx.getItems().addAll(transmisiones);  // Cambiar aquí para llenar transCbx con transmisiones
        transCbx.getSelectionModel().selectFirst();
        cantidadPuertasCbx.getItems().addAll("-","4", "2");
        cantidadPuertasCbx.getSelectionModel().selectFirst();
        cantidadTxt.setValueFactory(cantidad);
        añoTxt.setValueFactory(añoValue);
        List<Estilo> estilos = VehiculosDAO.obtenerEstilos();
        estiloCbx.getItems().add("-");
        estiloCbx.getItems().addAll(estilos);
        estiloCbx.getSelectionModel().selectFirst();
        List<TipoVehiculo> tipo = VehiculosDAO.obtenerTiposVehiculo();
        tipoCbx.getItems().add("-");
        tipoCbx.getItems().addAll(tipo);
        tipoCbx.getSelectionModel().selectFirst();

        numerosSolo(idTxt);
        numerosSolo(precioTxt);


//        date.valueProperty().addListener((observable, oldValue, newValue) -> calcularEdad(newValue));
//        numerosSolo();
//        date.setEditable(false);


    }


    @javafx.fxml.FXML
    public void btnLimpiarOnAction(ActionEvent actionEvent) {
        añoValue.setValue(2024);
        cantidad.setValue(1);
        cantidadPuertasCbx.getSelectionModel().selectFirst();

    }

    @javafx.fxml.FXML
    public void btnAgregarOnAction(ActionEvent actionEvent) {
//        if (isValid()){
//            int cedula = Integer.parseInt(cedulaTxt.getText());
//            String nombre = nombreTxt.getText();
//            String apellido1 = apellido1Txt.getText();
//            String apellido2 = apellido2Txt.getText();
//            Date fecNacimiento = Date.valueOf(date.getValue());
//            int edad = Integer.parseInt(edadTxt.getText());
//
//            Medico medico = new Medico(cedula, nombre, apellido1, apellido2, fecNacimiento, edad);
//            MedicoDAO.insertMedico(medico);
//
////            gestionMedicoController.seteo();
//            gestionStockController.stage.close();
//        }

    }

    @javafx.fxml.FXML
    public void btnCancelarOnAction(ActionEvent actionEvent) {
        gestionStockController.stage.close();
    }

    public void addController(GestionStockController gestionStockController) {
        this.gestionStockController = gestionStockController;
    }

    public void numerosSolo(TextField cedulaTxt) {
        TextFormatter<Integer> textFormatter = new TextFormatter<>(new IntegerStringConverter(), null);
        cedulaTxt.setTextFormatter(textFormatter);

        textFormatter.valueProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue == null) {
                cedulaTxt.setText("");
            }
        });

        cedulaTxt.textProperty().addListener((obs, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                cedulaTxt.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }

//    private boolean isValid() {
//        if (cedulaTxt.getText().length() != 9){
//            alert.setContentText("Ingrese una cedula válida");
//            alert.show();
//        } else if (MedicoDAO.medicoExists(Integer.parseInt(cedulaTxt.getText()))){
//            alert.setContentText("Ya existe un medico registrado con ese numero de cedula");
//            alert.show();
//        } else if (!apellido2Txt.getText().isEmpty() && date.getValue() != null && !edadTxt.getText().isEmpty()
//                && !nombreTxt.getText().isEmpty() && !apellido1Txt.getText().isEmpty() && !cedulaTxt.getText().isEmpty())
//                 {
//            return true;
//        } else {
//            alert.setContentText("Complete todos los campos");
//            alert.show();
//        }
//
//        return false;
//    }
//    }
}