package controller.agregar;

import controller.gestion.GestionStockController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.converter.IntegerStringConverter;
import model.hospitales.Paciente;
import model.hospitales.TelefonosPaciente;
import service.hospitales.PacienteDAO;
import service.hospitales.TelefonosPacienteDAO;

import java.time.LocalDate;
import java.time.Period;
import java.sql.Date;

public class AgregarUsuarioController
{

    @FXML
    private Label Alerta;
    @FXML
    private TextField apellido2Txt;
    @FXML
    private DatePicker date;
    @FXML
    private Label edadTxt;
    @FXML
    private TextField nombreTxt;
    @FXML
    private TextField apellido1Txt;
    @FXML
    private TextField cedulaTxt;
    @FXML
    private TextField telefonoTxt;
    @FXML
    private TextField telefonoOpcionalTxt;

    private Alert alert;

    private GestionStockController gestionUsuariosController;
    ObservableList<Paciente> pacientes = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        this.alert = new Alert(Alert.AlertType.WARNING);
        this.alert.setHeaderText(null);
        this.alert.setTitle("Alerta");
        date.valueProperty().addListener((observable, oldValue, newValue) -> calcularEdad(newValue));
        numerosSolo(cedulaTxt);
        numerosSolo(telefonoTxt);
        numerosSolo(telefonoOpcionalTxt);
        date.setEditable(false);
    }

    @FXML
    public void btnLimpiarOnAction(ActionEvent actionEvent) {
        apellido2Txt.setText("");
        date.setValue(null);
        edadTxt.setText("");
        nombreTxt.setText("");
        apellido1Txt.setText("");
        cedulaTxt.setText("");
        telefonoTxt.clear();
        telefonoOpcionalTxt.clear();
        Alerta.setText("");
    }

    @FXML
    public void btnAgregarOnAction(ActionEvent actionEvent) {

        if (isValid()){
            int cedula = Integer.parseInt(cedulaTxt.getText());
            String nombre = nombreTxt.getText();
            String apellido1 = apellido1Txt.getText();
            String apellido2 = apellido2Txt.getText();
            Date fecNacimiento = Date.valueOf(date.getValue());
            int edad = Integer.parseInt(edadTxt.getText());
            int telefono = Integer.parseInt(telefonoTxt.getText());

            Paciente paciente = new Paciente(cedula, nombre, apellido1, apellido2, fecNacimiento, edad);
            PacienteDAO.insertPaciente(paciente);

            TelefonosPaciente telefonosPaciente = new TelefonosPaciente(cedula, telefono);
            TelefonosPacienteDAO.insertTelefonoPaciente(telefonosPaciente);

            if (!telefonoOpcionalTxt.getText().isEmpty()){
                int telefono2 = Integer.parseInt(telefonoOpcionalTxt.getText());
                TelefonosPaciente telefonosPaciente2 = new TelefonosPaciente(cedula, telefono2);
                TelefonosPacienteDAO.insertTelefonoPaciente(telefonosPaciente2);
            }

//            gestionUsuariosController.seteo();
            gestionUsuariosController.stage.close();
        }

    }

    @FXML
    public void btnCancelarOnAction(ActionEvent actionEvent) {
        gestionUsuariosController.stage.close();
    }
    private void calcularEdad(LocalDate fechaNacimiento) {
        // Verifica si la fecha de nacimiento es válida
        if (fechaNacimiento != null) {
            // Calcula la edad usando la clase Period
            Period periodo = Period.between(fechaNacimiento, LocalDate.now());
            int edad = periodo.getYears();
            String ed = edad + "";

            // Actualiza el Label con la edad calculada
            edadTxt.setText(ed);
        } else {
            // Si la fecha de nacimiento es nula, muestra un mensaje indicando que la fecha es inválida
            edadTxt.setText("Fecha de nacimiento inválida");
        }
    }
    public void addController(GestionStockController gestionUsuariosController) {
        this.gestionUsuariosController = gestionUsuariosController;
        this.pacientes = pacientes;
    }
    public void numerosSolo(TextField cedulaTxt) {
        TextFormatter<Integer> textFormatter = new TextFormatter<>(new IntegerStringConverter(), null);
        cedulaTxt.setTextFormatter(textFormatter);

        textFormatter.valueProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue == null) {
                cedulaTxt.setText("");
            }
        });

        cedulaTxt.textProperty().addListener((obs, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                cedulaTxt.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }
    private boolean isValid(){
        if (cedulaTxt.getText().length() != 9){
            alert.setContentText("Ingrese una cedula válida");
            alert.show();
        } else if (PacienteDAO.pacienteExists(Integer.parseInt(cedulaTxt.getText()))){
            alert.setContentText("Ya existe un paciente registrado con ese numero de cedula");
            alert.show();
        } else if (telefonoTxt.getText().length() != 8) {
            alert.setContentText("Ingrese un teléfono válido");
            alert.show();
        } else if (!telefonoOpcionalTxt.getText().isEmpty() && telefonoOpcionalTxt.getText().length() != 8) {
            alert.setContentText("Ingrese un segundo teléfono válido");
            alert.show();
        } else if (!apellido2Txt.getText().isEmpty() && date.getValue() != null && !edadTxt.getText().isEmpty()
                && !nombreTxt.getText().isEmpty() && !apellido1Txt.getText().isEmpty() && !cedulaTxt.getText().isEmpty()
                && !telefonoTxt.getText().isEmpty()) {
            return true;
        } else {
            alert.setContentText("Complete todos los campos");
            alert.show();
        }

        return false;
    }
}