package controller.agregar;

import controller.gestion.GestionStockController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.text.Text;
import javafx.util.converter.IntegerStringConverter;
import model.hospitales.TelefonosPaciente;
import service.hospitales.PacienteDAO;
import service.hospitales.TelefonosPacienteDAO;

public class AgregarContactoController {

    public Text nombreTxt;
    @FXML
    private TextField cedulaTxt;
    private GestionStockController gestionUsuariosController;
    @FXML
    private TextField telefonoTxt;
    private Alert alert;

    @FXML
    public void initialize() {
        this.alert = new Alert(Alert.AlertType.WARNING);
        this.alert.setHeaderText(null);
        this.alert.setTitle("Alerta");
        numerosSolo();
        numerosSoloTelefono();
    }

    @FXML
    public void btnLimpiarOnAction(ActionEvent actionEvent) {
        cedulaTxt.clear();
        telefonoTxt.clear();
    }

    @FXML
    public void btnAgregarOnAction(ActionEvent actionEvent) {
        if (isValid()){
            TelefonosPaciente pacienteNuevo = new TelefonosPaciente(Integer.parseInt(cedulaTxt.getText()), Integer.parseInt(telefonoTxt.getText()));
            TelefonosPacienteDAO.insertTelefonoPaciente(pacienteNuevo);
//            gestionUsuariosController.seteo();
            gestionUsuariosController.stage.close();
        }

    }

    @FXML
    public void btnCancelarOnAction(ActionEvent actionEvent) {
        gestionUsuariosController.stage.close();
    }
    public void addController(GestionStockController gestionUsuariosController) {
        this.gestionUsuariosController = gestionUsuariosController;
    }
    public void numerosSolo() {
        TextFormatter<Integer> textFormatter = new TextFormatter<>(new IntegerStringConverter(), null);
        cedulaTxt.setTextFormatter(textFormatter);

        textFormatter.valueProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue == null) {
                cedulaTxt.setText("");
            }
        });

        cedulaTxt.textProperty().addListener((obs, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                cedulaTxt.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }
    public void numerosSoloTelefono() {
        TextFormatter<Integer> textFormatter = new TextFormatter<>(new IntegerStringConverter(), null);
        telefonoTxt.setTextFormatter(textFormatter);

        textFormatter.valueProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue == null) {
                telefonoTxt.setText("");
            }
        });

        telefonoTxt.textProperty().addListener((obs, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                telefonoTxt.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }
    private boolean isValid(){
        if (!cedulaTxt.getText().isEmpty() && !telefonoTxt.getText().isEmpty()) {
            int cedulaBuscada = Integer.parseInt(cedulaTxt.getText());
            int telefonoBuscado = Integer.parseInt(telefonoTxt.getText());
            boolean pacienteExist = PacienteDAO.pacienteExists(cedulaBuscada);
            boolean registerExist = TelefonosPacienteDAO.registerExist(cedulaBuscada, telefonoBuscado);

            if (cedulaTxt.getText().length() != 9){
                alert.setContentText("Ingrese una cedula válida");
                alert.show();
            } else if (telefonoTxt.getText().length() != 8) {
                alert.setContentText("Ingrese un numero de telefono valido");
                alert.show();
            } else if (registerExist){
                alert.setContentText("Ya existe ese registro, por favor, intente con otro");
                alert.show();
            } else if (!pacienteExist) {
                alert.setContentText("No hay ningun paciente registrado con esa cedula");
                alert.show();
            } else {
                return true;
            }

        }else {
                alert.setContentText("Complete todos los campos");
                alert.show();
        }

        return false;
    }
}