package controller.agregar;

import controller.gestion.GestionMedicoController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.text.Text;
import javafx.util.converter.IntegerStringConverter;
import model.hospitales.HospitalMedico;
import service.hospitales.HospitalDAO;
import service.hospitales.HospitalMedicoDAO;
import service.hospitales.MedicoDAO;

public class AgregarHospitalMedicoController {

    public Text nombreTxt;
    @FXML
    private TextField cedulaTxt;
    private GestionMedicoController gestionMedicoController;
    @FXML
    private TextField idHospitalTxt;
    private Alert alert;


    @FXML
    public void initialize() {
        this.alert = new Alert(Alert.AlertType.WARNING);
        this.alert.setHeaderText(null);
        this.alert.setTitle("Alerta");
        numerosSolo();
        numerosSoloTelefono();
    }

    @FXML
    public void btnLimpiarOnAction(ActionEvent actionEvent) {
        cedulaTxt.setText("");
        idHospitalTxt.setText("");
    }

    @FXML
    public void btnAgregarOnAction(ActionEvent actionEvent) {
        if (isValid()){
            int cedula = Integer.parseInt(cedulaTxt.getText());
            int idHospital = Integer.parseInt(idHospitalTxt.getText());

            HospitalMedico hospitalMedico = new HospitalMedico(cedula, idHospital);
            HospitalMedicoDAO.insertHospitalMedico(hospitalMedico);

            gestionMedicoController.seteo();
            gestionMedicoController.stage.close();
        }

    }

    @FXML
    public void btnCancelarOnAction(ActionEvent actionEvent) {
        gestionMedicoController.stage.close();
    }
    public void addController(GestionMedicoController gestionUsuariosController) {
        this.gestionMedicoController = gestionUsuariosController;
    }
    public void numerosSolo() {
        TextFormatter<Integer> textFormatter = new TextFormatter<>(new IntegerStringConverter(), null);
        cedulaTxt.setTextFormatter(textFormatter);

        textFormatter.valueProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue == null) {
                cedulaTxt.setText("");
            }
        });

        cedulaTxt.textProperty().addListener((obs, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                cedulaTxt.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }
    public void numerosSoloTelefono() {
        TextFormatter<Integer> textFormatter = new TextFormatter<>(new IntegerStringConverter(), null);
        idHospitalTxt.setTextFormatter(textFormatter);

        textFormatter.valueProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue == null) {
                idHospitalTxt.setText("");
            }
        });

        idHospitalTxt.textProperty().addListener((obs, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                idHospitalTxt.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }
    private boolean isValid(){
        if (!cedulaTxt.getText().isEmpty() && !idHospitalTxt.getText().isEmpty()) {
            int cedulaBuscada = Integer.parseInt(cedulaTxt.getText());
            int idBuscado = Integer.parseInt(idHospitalTxt.getText());
            boolean medicoExist = MedicoDAO.medicoExists(cedulaBuscada);
            boolean medicoExistRegister = HospitalMedicoDAO.medicoExist(cedulaBuscada);
            boolean hospitalExist = HospitalDAO.hospitalExists(idBuscado);
            boolean registerExist = HospitalMedicoDAO.registerExist(cedulaBuscada, idBuscado);

            if (cedulaTxt.getText().length() != 9){
                alert.setContentText("Ingrese una cedula válida");
                alert.show();
            }  else if (registerExist){
                alert.setContentText("Ya existe ese registro, por favor, intente con otro");
                alert.show();
            } else if (!medicoExist) {
                alert.setContentText("No hay ningun medico registrado con esa cedula");
                alert.show();
            } else if (!hospitalExist) {
                alert.setContentText("No hay ningun hospital registrado con ese ID");
                alert.show();
            } else if (medicoExistRegister) {
                alert.setContentText("No puede ingresar el mismo medico más de una vez");
                alert.show();
            }else {
                return true;
            }

        }else {
            alert.setContentText("Complete todos los campos");
            alert.show();
        }

        return false;
    }
}