package controller;

import javafx.geometry.Insets;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import service.VehiculosDAO;
import ucr.proyectobases.HelloApplication;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.layout.CornerRadii;
import javafx.geometry.Insets;

import java.io.IOException;

public class HelloController {
    @FXML
    private AnchorPane ap;
    @FXML
    private BorderPane bp;
    BackgroundFill backgroundFill = new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY);
    Background backgroundGray = new Background(backgroundFill);

    BackgroundImage backgroundImage = new BackgroundImage(
            new Image("Fondo(1).jpg"),
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.CENTER,
            new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false)
    );
    Background backgroundWithImage = new Background(backgroundImage);

    private void loadPage(String page) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource(page));
        try {
            this.bp.setCenter(fxmlLoader.load());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    @Deprecated
    void Exit(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    @Deprecated
    void Home(ActionEvent event) {
        this.bp.setCenter(ap);
        this.bp.setBackground(backgroundWithImage);
    }

    public void VentasOnAction(ActionEvent actionEvent) {
        loadPage("gestionStock.fxml");
        this.bp.setBackground(backgroundGray);
    }

    public void StockOnAction(ActionEvent actionEvent) {
        loadPage("gestionMedico.fxml");
    }
}
