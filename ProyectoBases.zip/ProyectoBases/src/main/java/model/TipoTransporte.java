package model;

public class TipoTransporte {
    private int idTipoTransporte;
    private String tipoTransporte;

    public TipoTransporte(int idTipoTransporte, String tipoTransporte) {
        this.idTipoTransporte = idTipoTransporte;
        this.tipoTransporte = tipoTransporte;
    }

    public int getIdTipoTransporte() {
        return idTipoTransporte;
    }

    public void setIdTipoTransporte(int idTipoTransporte) {
        this.idTipoTransporte = idTipoTransporte;
    }

    public String getTipoTransporte() {
        return tipoTransporte;
    }

    public void setTipoTransporte(String tipoTransporte) {
        this.tipoTransporte = tipoTransporte;
    }
}
