package model;

public class DetaVenta {
    private int idDetaVenta;
    private int idEncaVenta;
    private int idVehiculo;
    private int cantidad;
    private double precioBruto;
    private double impuestos;
    private double descuentos;
    private double precioFinal;

    public DetaVenta(int idDetaVenta, int idEncaVenta, int idVehiculo, int cantidad, double precioBruto,
                     double impuestos, double descuentos, double precioFinal) {
        this.idDetaVenta = idDetaVenta;
        this.idEncaVenta = idEncaVenta;
        this.idVehiculo = idVehiculo;
        this.cantidad = cantidad;
        this.precioBruto = precioBruto;
        this.impuestos = impuestos;
        this.descuentos = descuentos;
        this.precioFinal = precioFinal;
    }

    public int getIdDetaVenta() {
        return idDetaVenta;
    }

    public void setIdDetaVenta(int idDetaVenta) {
        this.idDetaVenta = idDetaVenta;
    }

    public int getIdEncaVenta() {
        return idEncaVenta;
    }

    public void setIdEncaVenta(int idEncaVenta) {
        this.idEncaVenta = idEncaVenta;
    }

    public int getIdVehiculo() {
        return idVehiculo;
    }

    public void setIdVehiculo(int idVehiculo) {
        this.idVehiculo = idVehiculo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecioBruto() {
        return precioBruto;
    }

    public void setPrecioBruto(double precioBruto) {
        this.precioBruto = precioBruto;
    }

    public double getImpuestos() {
        return impuestos;
    }

    public void setImpuestos(double impuestos) {
        this.impuestos = impuestos;
    }

    public double getDescuentos() {
        return descuentos;
    }

    public void setDescuentos(double descuentos) {
        this.descuentos = descuentos;
    }

    public double getPrecioFinal() {
        return precioFinal;
    }

    public void setPrecioFinal(double precioFinal) {
        this.precioFinal = precioFinal;
    }
}
