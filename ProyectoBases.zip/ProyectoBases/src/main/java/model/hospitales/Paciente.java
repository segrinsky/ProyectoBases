package model.hospitales;

import java.time.LocalDate;
import java.sql.Date;

public class Paciente {
    private int cedula;
    private String nombre;
    private String apellido1;
    private String apellido2;
    private Date fecNacimiento;
    private int edad;

    public Paciente(int cedula, String nombre, String apellido1, String apellido2, Date fec_Nacimiento, int edad) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        fecNacimiento = fec_Nacimiento;
        this.edad = edad;
    }

    public Paciente() {
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    @Override
    public String toString() {
        return "Paciente{" +
                "Cedula=" + cedula +
                ", Nombre='" + nombre + '\'' +
                ", Apellido_1='" + apellido1 + '\'' +
                ", Apellido_2='" + apellido2 + '\'' +
                ", Fec_Nacimiento=" + fecNacimiento +
                ", Edad=" + edad +
                '}';
    }

    public Date getFecNacimiento() {
        return fecNacimiento;
    }

    public void setFecNacimiento(Date fecNacimiento) {
        this.fecNacimiento = fecNacimiento;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
}
