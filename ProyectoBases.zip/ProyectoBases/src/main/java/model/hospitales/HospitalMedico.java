package model.hospitales;

public class HospitalMedico {
    private int cedula;
    private int idHospital;

    public HospitalMedico(int cedula, int idHospital) {
        this.cedula = cedula;
        this.idHospital = idHospital;
    }

    public HospitalMedico() {}

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public int getIdHospital() {
        return idHospital;
    }

    public void setIdHospital(int idHospital) {
        this.idHospital = idHospital;
    }
}
