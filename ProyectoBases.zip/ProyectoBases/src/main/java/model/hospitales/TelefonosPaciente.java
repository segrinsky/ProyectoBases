package model.hospitales;

public class TelefonosPaciente {
    private int cedula;
    private int telefono;

    public TelefonosPaciente(int cedula, int telefono) {
        this.cedula = cedula;
        this.telefono = telefono;
    }

    public TelefonosPaciente() {
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "TelefonosPaciente{" +
                "cedula=" + cedula +
                ", telefono=" + telefono +
                '}';
    }
}
