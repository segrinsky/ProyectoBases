package model.hospitales;
public class Hospital {
    private int idHospital;
    private String nombre;
    private String direccion;

    public Hospital(int idHospital, String nombre, String direccion) {
        this.idHospital = idHospital;
        this.nombre = nombre;
        this.direccion = (direccion.length() > 100) ? direccion.substring(0, 100) : direccion;
    }

    public Hospital(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public Hospital() {}

    public void setIdHospital(int idHospital) {
        this.idHospital = idHospital;
    }

    public int getIdHospital() {
        return idHospital;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = (direccion.length() > 100) ? direccion.substring(0, 100) : direccion;
    }

    @Override
    public String toString() {
        return "ID_HOSPITAL: " + idHospital +
                ", NOMBRE: " + nombre +
                ", DIRECCION: " + direccion ;
    }
}
