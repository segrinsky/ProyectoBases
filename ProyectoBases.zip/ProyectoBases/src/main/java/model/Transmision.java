package model;

public class Transmision {
    private int idTransmision;
    private String transmision;

    public Transmision(int idTransmision, String transmision) {
        this.idTransmision = idTransmision;
        this.transmision = transmision;
    }

    public int getIdTransmision() {
        return idTransmision;
    }

    public void setIdTransmision(int idTransmision) {
        this.idTransmision = idTransmision;
    }

    public String getTransmision() {
        return transmision;
    }

    public void setTransmision(String transmision) {
        this.transmision = transmision;
    }

    @Override
    public String toString() {
        return transmision;
    }

}
