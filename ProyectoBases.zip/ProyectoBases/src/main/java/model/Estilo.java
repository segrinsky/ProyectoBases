package model;

public class Estilo {
    private int idEstilo;
    private String estilo;

    public Estilo(int idEstilo, String estilo) {
        this.idEstilo = idEstilo;
        this.estilo = estilo;
    }

    public int getIdEstilo() {
        return idEstilo;
    }

    public void setIdEstilo(int idEstilo) {
        this.idEstilo = idEstilo;
    }

    public String getEstilo() {
        return estilo;
    }

    public void setEstilo(String estilo) {
        this.estilo = estilo;
    }

    @Override
    public String toString() {
        return estilo;
    }
}
