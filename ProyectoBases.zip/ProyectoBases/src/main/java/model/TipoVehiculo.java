package model;
public class TipoVehiculo {
    private int idTipoVehiculo;
    private int idTipoTransporte;
    private String tipoVehiculo;

    public TipoVehiculo(int idTipoVehiculo, int idTipoTransporte, String tipoVehiculo) {
        this.idTipoVehiculo = idTipoVehiculo;
        this.idTipoTransporte = idTipoTransporte;
        this.tipoVehiculo = tipoVehiculo;
    }

    public int getIdTipoVehiculo() {
        return idTipoVehiculo;
    }

    public void setIdTipoVehiculo(int idTipoVehiculo) {
        this.idTipoVehiculo = idTipoVehiculo;
    }

    public int getIdTipoTransporte() {
        return idTipoTransporte;
    }

    public void setIdTipoTransporte(int idTipoTransporte) {
        this.idTipoTransporte = idTipoTransporte;
    }

    public String getTipoVehiculo() {
        return tipoVehiculo;
    }

    public void setTipoVehiculo(String tipoVehiculo) {
        this.tipoVehiculo = tipoVehiculo;
    }

    @Override
    public String toString() {
        return tipoVehiculo ;
    }
}
