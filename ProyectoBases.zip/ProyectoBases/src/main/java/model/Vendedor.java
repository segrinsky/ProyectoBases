package model;

public class Vendedor {
    private int idVendedor;
    private int idEmpleado;
    private int idAgencia;

    public Vendedor(int idVendedor, int idEmpleado, int idAgencia) {
        this.idVendedor = idVendedor;
        this.idEmpleado = idEmpleado;
        this.idAgencia = idAgencia;
    }

    public int getIdVendedor() {
        return idVendedor;
    }

    public void setIdVendedor(int idVendedor) {
        this.idVendedor = idVendedor;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public int getIdAgencia() {
        return idAgencia;
    }

    public void setIdAgencia(int idAgencia) {
        this.idAgencia = idAgencia;
    }
}
