package model;

import java.util.Date;

public class Empleado {
    private int idEmpleado;
    private String empleado;
    private String email;
    private String cedula;
    private String indActivo;
    private int idDepartamento;
    private int idPuesto;
    private byte[] clave;
    private double salario;
    private Date fechaRegistro;

    public Empleado(int idEmpleado, String empleado, String email, String cedula, String indActivo,
                    int idDepartamento, int idPuesto, byte[] clave, double salario, Date fechaRegistro) {
        this.idEmpleado = idEmpleado;
        this.empleado = empleado;
        this.email = email;
        this.cedula = cedula;
        this.indActivo = indActivo;
        this.idDepartamento = idDepartamento;
        this.idPuesto = idPuesto;
        this.clave = clave;
        this.salario = salario;
        this.fechaRegistro = fechaRegistro;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getEmpleado() {
        return empleado;
    }

    public void setEmpleado(String empleado) {
        this.empleado = empleado;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getIndActivo() {
        return indActivo;
    }

    public void setIndActivo(String indActivo) {
        this.indActivo = indActivo;
    }

    public int getIdDepartamento() {
        return idDepartamento;
    }

    public void setIdDepartamento(int idDepartamento) {
        this.idDepartamento = idDepartamento;
    }

    public int getIdPuesto() {
        return idPuesto;
    }

    public void setIdPuesto(int idPuesto) {
        this.idPuesto = idPuesto;
    }

    public byte[] getClave() {
        return clave;
    }

    public void setClave(byte[] clave) {
        this.clave = clave;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }
}
