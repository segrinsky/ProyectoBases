package model;


public class Vehiculo {
    private int idVehiculo;
    private String tipoVehiculo;
    private String estilo;
    private String transmision;
    private String descripcion;
    private int cantidad;
    private String anoFabricacion;
    private int cantidadPuertas;
    private double precio;

    public Vehiculo(int idVehiculo, String tipoVehiculo, String estilo, String transmision, String descripcion,
                    int cantidad, String anoFabricacion, int cantidadPuertas, double precio) {
        this.idVehiculo = idVehiculo;
        this.tipoVehiculo = tipoVehiculo;
        this.estilo = estilo;
        this.transmision = transmision;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        this.anoFabricacion = anoFabricacion;
        this.cantidadPuertas = cantidadPuertas;
        this.precio = precio;
    }

    public int getIdVehiculo() {
        return idVehiculo;
    }

    public void setIdVehiculo(int idVehiculo) {
        this.idVehiculo = idVehiculo;
    }

    public String getTipoVehiculo() {
        return tipoVehiculo;
    }

    public void setTipoVehiculo(String tipoVehiculo) {
        this.tipoVehiculo = tipoVehiculo;
    }

    public String getEstilo() {
        return estilo;
    }

    public void setEstilo(String estilo) {
        this.estilo = estilo;
    }

    public String getTransmision() {
        return transmision;
    }

    public void setTransmision(String transmision) {
        this.transmision = transmision;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getAnoFabricacion() {
        return anoFabricacion;
    }

    public void setAnoFabricacion(String anoFabricacion) {
        this.anoFabricacion = anoFabricacion;
    }

    public int getCantidadPuertas() {
        return cantidadPuertas;
    }

    public void setCantidadPuertas(int cantidadPuertas) {
        this.cantidadPuertas = cantidadPuertas;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Vehiculo{" +
                "idVehiculo=" + idVehiculo +
                ", tipoVehiculo='" + tipoVehiculo + '\'' +
                ", estilo='" + estilo + '\'' +
                ", transmision='" + transmision + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", cantidad=" + cantidad +
                ", anoFabricacion='" + anoFabricacion + '\'' +
                ", cantidadPuertas=" + cantidadPuertas +
                ", precio=" + precio +
                '}';
    }
}
