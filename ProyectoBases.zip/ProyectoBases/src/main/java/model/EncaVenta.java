package model;

import java.util.Date;

public class EncaVenta {
    private int idEncaVenta;
    private int idVendedor;
    private Date fechaVenta;
    private double precioTotal;

    public EncaVenta(int idEncaVenta, int idVendedor, Date fechaVenta, double precioTotal) {
        this.idEncaVenta = idEncaVenta;
        this.idVendedor = idVendedor;
        this.fechaVenta = fechaVenta;
        this.precioTotal = precioTotal;
    }

    public int getIdEncaVenta() {
        return idEncaVenta;
    }

    public void setIdEncaVenta(int idEncaVenta) {
        this.idEncaVenta = idEncaVenta;
    }

    public int getIdVendedor() {
        return idVendedor;
    }

    public void setIdVendedor(int idVendedor) {
        this.idVendedor = idVendedor;
    }

    public Date getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(Date fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public double getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(double precioTotal) {
        this.precioTotal = precioTotal;
    }
}
