package model;

public class Agencia {
    private int idAgencia;
    private String idPais;
    private String agencia;

    public Agencia(int idAgencia, String idPais, String agencia) {
        this.idAgencia = idAgencia;
        this.idPais = idPais;
        this.agencia = agencia;
    }

    public int getIdAgencia() {
        return idAgencia;
    }

    public void setIdAgencia(int idAgencia) {
        this.idAgencia = idAgencia;
    }

    public String getIdPais() {
        return idPais;
    }

    public void setIdPais(String idPais) {
        this.idPais = idPais;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }
}
