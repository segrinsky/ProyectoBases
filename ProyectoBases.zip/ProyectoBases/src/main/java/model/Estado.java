package model;

public class Estado {
    private int idEstado;
    private String estados;

    public Estado(int idEstado, String estados) {
        this.idEstado = idEstado;
        this.estados = estados;
    }

    public int getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(int idEstado) {
        this.idEstado = idEstado;
    }

    public String getEstados() {
        return estados;
    }

    public void setEstados(String estados) {
        this.estados = estados;
    }
}
