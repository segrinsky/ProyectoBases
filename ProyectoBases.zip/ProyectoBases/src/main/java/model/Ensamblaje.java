package model;

import java.util.Date;

public class Ensamblaje {
    private int idEnsamblaje;
    private int idTipoVehiculo;
    private Date fechaInicio;
    private Date fechaFin;
    private int idEstado;

    public Ensamblaje(int idEnsamblaje, int idTipoVehiculo, Date fechaInicio, Date fechaFin, int idEstado) {
        this.idEnsamblaje = idEnsamblaje;
        this.idTipoVehiculo = idTipoVehiculo;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.idEstado = idEstado;
    }

    public int getIdEnsamblaje() {
        return idEnsamblaje;
    }

    public void setIdEnsamblaje(int idEnsamblaje) {
        this.idEnsamblaje = idEnsamblaje;
    }

    public int getIdTipoVehiculo() {
        return idTipoVehiculo;
    }

    public void setIdTipoVehiculo(int idTipoVehiculo) {
        this.idTipoVehiculo = idTipoVehiculo;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public int getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(int idEstado) {
        this.idEstado = idEstado;
    }
}
